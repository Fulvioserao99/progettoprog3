package com.example.robot_3.FactoryMethod;

public interface ILabyrinth {
    public void generateLab();
    public void createGraph();

}
