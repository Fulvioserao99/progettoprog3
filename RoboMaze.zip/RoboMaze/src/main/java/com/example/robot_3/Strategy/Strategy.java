package com.example.robot_3.Strategy;

import com.example.robot_3.LabInteractors.Cell;

import java.util.ArrayList;

public interface Strategy {
    ArrayList<Integer> calculateNextMove(Cell cell);
}
