package com.example.robot_3;

import com.example.robot_3.Command.LabInvoker;
import com.example.robot_3.Command.LoadEasyLab;
import com.example.robot_3.Command.LoadHardLab;
import com.example.robot_3.Command.LoadMediumLab;
import com.example.robot_3.Proxy.IFile;
import com.example.robot_3.Proxy.ProxyFileScoreboard;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class HelloApplication extends Application {
    @FXML
    ListView<String> viewEasy;
    @FXML
    ListView<String> viewMed;
    @FXML
    ListView<String> viewHard;
    @FXML
    Button playBTN, helpBTN, exitBTN, easyBTN, mediumBTN, hardBTN, backBTN;
    @FXML
    TextField name,lastName;
    @FXML
    Pane rulesPane;
    @FXML
    Pane playMainMenu;

    LabInvoker invoker = new LabInvoker();

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main-menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setResizable(false);
        stage.setTitle("RoboMaze");
        stage.setScene(scene);
        stage.show();

    }

    private void makePlayMenuVis() { playMainMenu.setVisible(true); }

    private void makePlayMenuInv() { playMainMenu.setVisible(false); }

    private void makeStartButtonsInv(){
        playBTN.setVisible(false);
        helpBTN.setVisible(false);
        exitBTN.setVisible(false);
    }

    private void makeStartButtonsVis(){
        playBTN.setVisible(true);
        helpBTN.setVisible(true);
        exitBTN.setVisible(true);
    }
    private void makeBackBttnVis()
    {
        backBTN.setVisible(true);
    }

    private void makeBackBttnInvis() { backBTN.setVisible(false); }

    private void makeRulesPaneVis()
    {
        rulesPane.setVisible(true);
    }

    private void makeRulesPaneInvis() {rulesPane.setVisible(false);}

    private void setContentToView(ListView<String> list, String filename) throws IOException {
        IFile scoreboard = new ProxyFileScoreboard(filename);
        ArrayList<String> s = ProxyFileScoreboard.listViewRead(scoreboard);
        list.getItems().addAll(s);
    }

    //Metodo che regola la visualizzazione dell'interfaccia grafica una volta premuto il bottone "Play" del main menu.
    @FXML
    public void playScene() throws IOException {
        makeBackBttnVis();
        makeStartButtonsInv();
        makePlayMenuVis();
        listLoad();
        listVisible();
    }

    private void listLoad() throws IOException {
        if(viewEasy.getItems().isEmpty())
            setContentToView(viewEasy,"easyscore.txt");

        if(viewMed.getItems().isEmpty())
            setContentToView(viewMed,"mediumscore.txt");

        if(viewHard.getItems().isEmpty())
            setContentToView(viewHard,"hardscore.txt");
    }

    //Metodo per il controllo della corretta compilazione del campo "Nome" nel main menu.
    @FXML
    public void canPlayText1(){
        if(!Objects.equals(lastName.getText(), "")){
            easyBTN.setDisable(false);
            mediumBTN.setDisable(false);
            hardBTN.setDisable(false);
        }
    }

    //Metodo per il controllo della corretta compilazione del campo "Cognome" nel main menu.
    @FXML
    public void canPlayText2(){
        if(!Objects.equals(name.getText(), "")){
            easyBTN.setDisable(false);
            mediumBTN.setDisable(false);
            hardBTN.setDisable(false);
        }
    }

    //Metodo per le funzionalità del bottone "Exit" nel main menu.
    @FXML
    public void exit(ActionEvent event)
    {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    //Metodo per il caricamento del labirinto livello di difficoltà facile.
    @FXML
    public void easyPlay(ActionEvent event) throws IOException {

        invoker.execute(event, new LoadEasyLab(name.getText(),lastName.getText(),"easyscore.txt"));

    }
    //Metodo per il caricamento del labirinto livello di difficoltà medio.
    @FXML
    public void mediumPlay(ActionEvent event) throws IOException {

        invoker.execute(event, new LoadMediumLab(name.getText(),lastName.getText(),"mediumscore.txt"));

    }
    //Metodo per il caricamento del labirinto livello di difficoltà difficile.
    @FXML
    public void hardPlay(ActionEvent event) throws IOException {

        invoker.execute(event, new LoadHardLab(name.getText(),lastName.getText(),"hardscore.txt"));

    }

    @FXML
    public void onBackButton()
    {
        makeBackBttnInvis();
        makeStartButtonsVis();
        makePlayMenuInv();
        makeRulesPaneInvis();
        listInvisible();
    }

    @FXML
    public void onHelpButton()
    {
        makeStartButtonsInv();
        makeRulesPaneVis();
        makeBackBttnVis();
    }

    @FXML
    public void listVisible()
    {
        viewEasy.setVisible(true);
        viewMed.setVisible(true);
        viewHard.setVisible(true);
    }

    @FXML
    public void listInvisible()
    {
        viewEasy.setVisible(false);
        viewMed.setVisible(false);
        viewHard.setVisible(false);
    }


    public static void main(String[] args){
        launch();
    }
}