package com.example.robot_3;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.effect.ImageInput;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class HelloApplication extends Application {
    @FXML
    Label labelEasy,labelMed,labelHard,leaderboard;
    @FXML
    ListView<String> viewEasy;
    @FXML
    ListView<String> viewMed,viewHard;

    @FXML
    Button playBTN, optionsBTN, exitBTN, easyBTN, mediumBTN, hardBTN, backBTN;

    @FXML
    TextField Text1,Text2;

    @FXML
    Label Label1,Label2;

    @FXML
    Pane rulesPane;

    LabInvoker invoker = new LabInvoker();

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main-menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setResizable(false);
        stage.setTitle("RoboMaze");
        stage.setScene(scene);
        stage.show();
    }

    private void makeLabelsVisible(){

        labelEasy.setVisible(true);
        labelMed.setVisible(true);
        labelHard.setVisible(true);
        Label1.setVisible(true);
        Label2.setVisible(true);
        leaderboard.setVisible(true);
    }

    private void makeLabelsInv(){

        labelEasy.setVisible(false);
        labelMed.setVisible(false);
        labelHard.setVisible(false);
        Label1.setVisible(false);
        Label2.setVisible(false);
        leaderboard.setVisible(false);
    }

    private void makeStartButtonsInv(){

        playBTN.setVisible(false);
        optionsBTN.setVisible(false);
        exitBTN.setVisible(false);

    }

    private void makeStartButtonsVis(){

        playBTN.setVisible(true);
        optionsBTN.setVisible(true);
        exitBTN.setVisible(true);
    }

    private void makeViewsVis(){

        viewEasy.setVisible(true);
        viewMed.setVisible(true);
        viewHard.setVisible(true);

    }

    private void makeViewsInv(){

        viewEasy.setVisible(false);
        viewMed.setVisible(false);
        viewHard.setVisible(false);

    }

    private void makeTextFieldVis(){

        Text1.setVisible(true);
        Text2.setVisible(true);

    }

    private void makeTextFieldInvis(){

        Text1.setVisible(false);
        Text2.setVisible(false);

    }

    private void makeDiffBtnsVisible(){

        easyBTN.setVisible(true);
        mediumBTN.setVisible(true);
        hardBTN.setVisible(true);

    }

    private void makeDiffBtnsInvisible(){

        easyBTN.setVisible(false);
        mediumBTN.setVisible(false);
        hardBTN.setVisible(false);

    }

    private void makeBackBttnVis()
    {
        backBTN.setVisible(true);
    }

    private void makeBackBttnInvis()
    {
        backBTN.setVisible(false);
    }

    private void makeRulesPaneVis()
    {
        rulesPane.setVisible(true);
    }

    private void makeRulesPaneInvis()
    {
        rulesPane.setVisible(false);
    }

    private void setContentToView(ListView<String> list, String filename) throws IOException {
        ProxyFileScoreboard file = new ProxyFileScoreboard(filename);
        ArrayList<String> s = file.listViewRead();
        list.getItems().addAll(s);
    }


    //Metodo che regola la visualizzazione dell'interfaccia grafica una volta premuto il bottone "Play" del main menu.
    @FXML
    public void playScene() throws IOException {

        makeBackBttnVis();
        makeStartButtonsInv();
        makeLabelsVisible();
        makeViewsVis();
        makeDiffBtnsVisible();
        makeTextFieldVis();
        setContentToView(viewEasy,"easyscore.txt");
        setContentToView(viewMed,"mediumscore.txt");
        setContentToView(viewHard,"hardscore.txt");

    }

    //Metodo per il controllo della corretta compilazione del campo "Nome" nel main menu.
    @FXML
    public void canPlayText1(){

        if(!Objects.equals(Text2.getText(), "")){
            easyBTN.setDisable(false);
            mediumBTN.setDisable(false);
            hardBTN.setDisable(false);
        }

    }

    //Metodo per il controllo della corretta compilazione del campo "Cognome" nel main menu.
    @FXML
    public void canPlayText2(){

        if(!Objects.equals(Text1.getText(), "")){
            easyBTN.setDisable(false);
            mediumBTN.setDisable(false);
            hardBTN.setDisable(false);
        }
    }

    //Metodo per le funzionalità del bottone "Exit" nel main menu.
    @FXML
    public void exit(ActionEvent event)
    {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    //Metodo per il caricamento del labirinto livello di difficoltà facile.
    @FXML
    public void easyPlay(ActionEvent event) throws IOException {

        invoker.execute(event, new LoadEasyLab(Text1.getText(),Text2.getText(),"easyscore.txt"));

    }
    //Metodo per il caricamento del labirinto livello di difficoltà medio.
    @FXML
    public void mediumPlay(ActionEvent event) throws IOException {

        invoker.execute(event, new LoadMediumLab(Text1.getText(),Text2.getText(),"mediumscore.txt"));

    }
    //Metodo per il caricamento del labirinto livello di difficoltà difficile.
    @FXML
    public void hardPlay(ActionEvent event) throws IOException {

        invoker.execute(event, new LoadHardLab(Text1.getText(),Text2.getText(),"hardscore.txt"));

    }

    @FXML
    public void onBackButton()
    {
        makeBackBttnInvis();
        makeStartButtonsVis();
        makeLabelsInv();
        makeViewsInv();
        makeDiffBtnsInvisible();
        makeTextFieldInvis();
        makeRulesPaneInvis();
    }

    @FXML
    public void onHelpButton()
    {
        makeStartButtonsInv();
        makeRulesPaneVis();
        makeBackBttnVis();
    }

    public static void main(String[] args){
        launch();
    }
}