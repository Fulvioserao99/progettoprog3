package com.example.robot_3;

import com.example.robot_3.Command.LabInvoker;
import com.example.robot_3.Command.LoadEasyLab;
import com.example.robot_3.Command.LoadHardLab;
import com.example.robot_3.Command.LoadMediumLab;
import com.example.robot_3.Proxy.IFile;
import com.example.robot_3.Proxy.ProxyFileScoreboard;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Classe che estende Application e che rappresenta la GUI*/
public class HelloApplication extends Application {

    /**
     * Le ListView utilizzate per le scoreboards*/
    @FXML
    ListView<String> viewEasy,viewMed,viewHard;

    /**
     * I bottoni presenti nell'interfaccia*/
    @FXML
    Button playBTN, helpBTN, exitBTN, easyBTN, mediumBTN, hardBTN, backBTN;

    /**
     * TextField per prendere in input nome e cognome*/
    @FXML
    TextField name,lastName;

    /**
     * I diversi pane che usa l'interfaccia*/
    @FXML
    Pane rulesPane,playMainMenu;

    /**
     * L'invoker del pattern Command*/
    private LabInvoker invoker = new LabInvoker();

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main-menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setResizable(false);
        stage.setTitle("RoboMaze");
        stage.setScene(scene);
        //playSound();
        stage.show();
    }

    /**
     * Metodo che cambia la visibilita' del pane del main menu'
     * @param bool bool da inserire nel setVisible*/
    private void makePlayMenuVis(Boolean bool) {
        playMainMenu.setVisible(bool);
    }

    /**
     * Metodo che cambia la visibilita' dei bottoni del menu'
     * @param bool bool da inserire nel setVisible*/
    private void makeStartButtonsVis(Boolean bool){
        playBTN.setVisible(bool);
        helpBTN.setVisible(bool);
        exitBTN.setVisible(bool);
    }

    /**
     * Metodo che cambia la visibilita' del bottone "back"
     * @param bool bool da inserire nel setVisible*/
    private void makeBackBttnVis(Boolean bool) {
        backBTN.setVisible(bool);
    }


    /**
     * Metodo che cambia la visibilita' del pane delle regole
     * @param bool bool da inserire nel setVisible*/
    private void makeRulesPaneVis(Boolean bool) {
        rulesPane.setVisible(bool);
    }


    /**
     * Metodo a basso livello, che riempie le ListView del contenuto delle scoreboards
     * @param list la ListView
     * @param filename il nome del file della scoreboard*/
    private void setContentToView(ListView<String> list, String filename) throws IOException {
        IFile scoreboard = new ProxyFileScoreboard(filename);
        ArrayList<String> s = ProxyFileScoreboard.listViewRead(scoreboard);
        list.getItems().addAll(s);
    }

    /**
     * Metodo che regola la visualizzazione dell'interfaccia grafica una volta premuto il bottone "Play" del main menu.*/
    @FXML
    public void playScene() throws IOException {
        makeBackBttnVis(true);
        makeStartButtonsVis(false);
        makePlayMenuVis(true);
        listLoad();
        listVisible(true);
    }

    /**
     * Metodo ad alto livello, che riempie le ListView, se queste sono vuote*/
    private void listLoad() throws IOException {
        if(viewEasy.getItems().isEmpty())
            setContentToView(viewEasy,"easyscore.txt");

        if(viewMed.getItems().isEmpty())
            setContentToView(viewMed,"mediumscore.txt");

        if(viewHard.getItems().isEmpty())
            setContentToView(viewHard,"hardscore.txt");
    }

    /**
     * Metodo per il controllo della corretta compilazione del campo "Nome" nel main menu.*/
    @FXML
    public void canPlayText1(){
        if(!Objects.equals(lastName.getText(), "")){
            easyBTN.setDisable(false);
            mediumBTN.setDisable(false);
            hardBTN.setDisable(false);
        }
    }

    /**
     * Metodo per il controllo della corretta compilazione del campo "Cognome" nel main menu.*/
    @FXML
    public void canPlayText2(){
        if(!Objects.equals(name.getText(), "")){
            easyBTN.setDisable(false);
            mediumBTN.setDisable(false);
            hardBTN.setDisable(false);
        }
    }

    /**
     * Metodo per le funzionalità del bottone "Exit" nel main menu.*/
    @FXML
    public void exit(ActionEvent event)
    {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    /**
     * Metodo per il caricamento del labirinto livello di difficoltà facile,
     * tramite l'invoker del pattern Command.
     * @param event l'evento trigger*/
    @FXML
    public void easyPlay(ActionEvent event) throws IOException {

        invoker.execute(event, new LoadEasyLab(name.getText(),lastName.getText(),"easyscore.txt"));

    }

    /**
     * Metodo per il caricamento del labirinto livello di difficoltà medio,
     * tramite l'invoker del pattern Command.
     * @param event l'evento trigger*/
    @FXML
    public void mediumPlay(ActionEvent event) throws IOException {

        invoker.execute(event, new LoadMediumLab(name.getText(),lastName.getText(),"mediumscore.txt"));

    }

    /**
     * Metodo per il caricamento del labirinto livello di difficoltà difficile,
     * tramite l'invoker del pattern Command.
     * @param event l'evento trigger*/
    @FXML
    public void hardPlay(ActionEvent event) throws IOException {

        invoker.execute(event, new LoadHardLab(name.getText(),lastName.getText(),"hardscore.txt"));

    }

    /**
     * Metodo che definisce la visibilita' di bottoni/panes/liste, alla
     * pressione del tasto "Back"*/
    @FXML
    public void onBackButton() {
        makeBackBttnVis(false);
        makeStartButtonsVis(true);
        makePlayMenuVis(false);
        makeRulesPaneVis(false);
        listVisible(false);
    }

    /**
     * Metodo che definisce la visibilita' di bottoni/panes/liste, alla
     * pressione del tasto "Help"*/
    @FXML
    public void onHelpButton()
    {
        makeStartButtonsVis(false);
        makeRulesPaneVis(true);
        makeBackBttnVis(true);
    }

    /**
     * Metodo che cambia la visibilita' delle ListView
     * @param bool bool da inserire nel setVisible*/
    @FXML
    public void listVisible(Boolean bool)
    {
        viewEasy.setVisible(bool);
        viewMed.setVisible(bool);
        viewHard.setVisible(bool);
    }

    /*private void playSound()
    {
        File media = new File("src/main/resources/music/Song_of_Storms.mp3");
        Media music = new Media(media);
    }*/

    public static void main(String[] args){
        launch();
    }
}