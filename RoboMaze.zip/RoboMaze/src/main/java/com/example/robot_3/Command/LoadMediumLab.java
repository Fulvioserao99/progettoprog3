package com.example.robot_3.Command;

import com.example.robot_3.HelloApplication;
import com.example.robot_3.LabController;
import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class LoadMediumLab extends LabCommand {


    public LoadMediumLab(String nome, String cognome, String filename){
        super(nome,cognome,filename);
        this.diff = 2;
    }
    @Override
    public void loadLab(Event event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("medium.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        LabController maze = new LabController(this);
        fxmlLoader.setController(maze);
        stage.setScene(new Scene(fxmlLoader.load()));
        stage.setMaximized(true);
        stage.setResizable(true);
    }
}
