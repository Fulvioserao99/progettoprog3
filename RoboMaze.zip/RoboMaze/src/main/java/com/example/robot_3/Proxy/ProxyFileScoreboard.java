package com.example.robot_3.Proxy;

import java.io.*;
import java.util.*;

/**
 * Classe Proxy del pattern Proxy, che imlementa l'interfaccia di servizio
 * e permette la gestione dei files relativi alle scoreboards*/
public class ProxyFileScoreboard implements IFile{

    /**
     * Il file della scoreboard*/
    private File scoreboard;

    /**
     * Nome del player*/
    private String nome;

    /**
     * Cognome del player*/
    private String cognome;

    /**
     * Punteggio del player*/
    private Integer punt;

    /**
     * Stringa che verra' inserita nel file*/
    private String putIntoFile;


    /**
     * Costruttore, che prende in input
     * @param filename il nome del file della scoreboard
     * @param nome nome del player
     * @param cognome cognome del player
     * @param punt punteggio del player*/
    public ProxyFileScoreboard(String filename, String nome, String cognome, Integer punt){
        scoreboard = new File(filename);
        this.nome = nome;
        this.cognome = cognome;
        this.punt = punt;
        putIntoFile = nome + " " + cognome + " - " + punt.toString();

    }

    /**
     * Costruttore alternativo, utilizzato per operazioni
     * di sola lettura, che prende in input
     * @param filename il nome del file della scoreboard*/
    public ProxyFileScoreboard(String filename){
        scoreboard = new File(filename);
    }


    /**
     * Metodo che crea un nuovo file se non esistente,
     * altrimenti non fa nulla*/
    private void open() throws IOException {
        scoreboard.createNewFile();
    }


    @Override
    public Boolean write() throws IOException{
        this.open();

        ArrayList<String> lineStrings = this.read();
            //se non e' stato letto nulla
            if(lineStrings.size() < 1){

                try (BufferedWriter out = new BufferedWriter(new FileWriter(scoreboard))) {
                    //scrivi la stringa e una nuova linea sul file
                    out.write(putIntoFile);
                    out.newLine();

                } catch (IOException e) {

                    System.out.println("Exception ");
                    return false;

                }
                return true;
            }
            else{
                int index = 0;
                boolean insert = false;
                for (String s:lineStrings) { //scorri tutte le stringhe
                    int d;
                    for(d=0; d< s.length(); d++)
                        if (s.charAt(d) == '-')
                            break; //fermati al ' - '
                    String token = s.substring(d);

                    if(Integer.parseInt(token.replaceAll("[\\D]", "")) > punt) { //se il punteggio attuale e' minore di quello trovato nel file
                        insert = true;
                        break; //hai trovato il punto, spezza
                    }
                    index++;
                }

                if(!insert) //se non hai trovato il punto, allora il punteggio e' il piu' grande -> sara' l'ultimo
                    lineStrings.add(putIntoFile);

                else
                    lineStrings.add(index,putIntoFile); //altrimenti inseriscilo all'indice corrispondente

            try (BufferedWriter out = new BufferedWriter(new FileWriter(scoreboard))) {

                for (int i = 0; i< lineStrings.size(); i++){
                    out.append(lineStrings.get(i));
                    out.newLine();
                }
            } catch (IOException e) {
                System.out.println("Exception ");
                return false;
            }

        }
        return true;

    }

    @Override
    public ArrayList<String> read() throws IOException{
        this.open();

        ArrayList<String> lineStrings = new ArrayList<>();

        BufferedReader reader;

        try {
            reader = new BufferedReader(new FileReader(scoreboard));
            String line = reader.readLine();

            while (line != null) {
                if(!line.isBlank()) //se la stringa non e' vuota / contiene solo spazi
                    lineStrings.add(line);
                line = reader.readLine();
            }
            reader.close();
            return lineStrings;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return lineStrings;
    }
    /**
     * Metodo statico che, dando in input un oggetto IFile, legge la scoreboard
     * e ne restituisce una versione piu' ordinata, per la visualizzazione a livello
     * grafico nelle listviews
     * @param scoreboard la scoreboard
     * @return ArrayList<String> una lista di stringhe, nella quale ognuna rappresenta
     * l'iesimo player col suo punteggio*/
    static public ArrayList<String> listViewRead(IFile scoreboard) throws IOException {
        ArrayList<String> strings,result;
        strings = scoreboard.read();
        result = strings;
        int pos = 0;
        for (String str:strings) {
            result.set(pos,str.replaceAll(" - ", "  "));
            pos++;
        }
        return result;
    }

}
