package com.example.robot_3.Proxy;

import java.io.*;
import java.util.*;

public class ProxyFileScoreboard implements IFile{

    File scoreboard;
    String nome;
    String cognome;
    Integer punt;

    String putIntoFile;



    public ProxyFileScoreboard(String filename, String nome, String cognome, Integer punt){
        scoreboard = new File(filename);
        this.nome = nome;
        this.cognome = cognome;
        this.punt = punt;
        putIntoFile = nome + " " + cognome + " - " + punt.toString();

    }

    public ProxyFileScoreboard(String filename){
        scoreboard = new File(filename);
    }


    private void open() throws IOException {
        scoreboard.createNewFile();
    }


    @Override
    public Boolean write() throws IOException{
        this.open();

        ArrayList<String> lineStrings = this.read();

            if(lineStrings.size() < 1){

                try (BufferedWriter out = new BufferedWriter(new FileWriter(scoreboard))) {

                    out.write(putIntoFile);
                    out.newLine();

                } catch (IOException e) {

                    System.out.println("Exception ");
                    return false;

                }
                return true;
            }
            else{
                int index = 0;
                boolean insert = false;
                for (String s:lineStrings) {
                    int d;
                    for(d=0; d< s.length(); d++)
                        if (s.charAt(d) == '-')
                            break;
                    String token = s.substring(d);

                    if(Integer.parseInt(token.replaceAll("[\\D]", "")) > punt) {
                        insert = true;
                        break;
                    }
                    index++;
                }

                if(!insert)

                    lineStrings.add(putIntoFile);
                else
                    lineStrings.add(index,putIntoFile);

            try (BufferedWriter out = new BufferedWriter(new FileWriter(scoreboard))) {

                for (int i = 0; i< lineStrings.size(); i++){
                    out.append(lineStrings.get(i));
                    out.newLine();
                }
            } catch (IOException e) {
                System.out.println("Exception ");
                return false;
            }

        }
        return true;

    }

    @Override
    public ArrayList<String> read() throws IOException{
        this.open();

        ArrayList<String> lineStrings = new ArrayList<>();

        BufferedReader reader;

        try {
            reader = new BufferedReader(new FileReader(scoreboard));
            String line = reader.readLine();

            while (line != null) {
                if(!line.isBlank())
                    lineStrings.add(line);
                line = reader.readLine();
            }
            reader.close();
            return lineStrings;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return lineStrings;
    }
    static public ArrayList<String> listViewRead(IFile scoreboard) throws IOException {
        ArrayList<String> strings,result;
        strings = scoreboard.read();
        result = strings;
        int pos = 0;
        for (String str:strings) {
            result.set(pos,str.replaceAll(" - ", "  "));
            pos++;
        }
        return result;
    }

}
