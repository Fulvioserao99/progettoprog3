package com.example.robot_3.LabInteractors;

import com.example.robot_3.State.State;

import java.util.ArrayList;

public class Robot{
    private State robotState;
    private State prevState;

    Cell actualCell;

    public Robot(Cell cell, State robotState){
        this.robotState = robotState;
        prevState = null;
        this.actualCell = cell;
    }

    public void setActualCell(Cell actualCell) {
        this.actualCell = actualCell;
    }

    public Position getPositionCoords(){
        return this.actualCell.getPos();
    }

    public Cell getActualCell() {
        return actualCell;
    }

    public CellVal getActualCellValue() {
        return actualCell.getValue();
    }

    public void setRobotState(State robotState) {
        this.robotState = robotState;
    }

    public State getRobotState() {
        return robotState;
    }

    public void setPrevState(State prevState) {
        this.prevState = prevState;
    }

    public State getPrevState() {
        return prevState;
    }
    public ArrayList<Integer> doAction(Cell cell) {
        return this.robotState.doAction(cell);
    }
}
