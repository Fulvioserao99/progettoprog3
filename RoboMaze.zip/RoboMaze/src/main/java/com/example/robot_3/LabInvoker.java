package com.example.robot_3;
import javafx.event.Event;
import java.io.IOException;

public class LabInvoker {

    LabCommand command;


    public void execute(Event event, LabCommand command) throws IOException {

        this.command = command;
        this.command.loadLab(event);

    }
}
