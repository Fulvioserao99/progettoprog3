package com.example.robot_3.Observer;

import com.example.robot_3.LabInteractors.Cell;
import com.example.robot_3.LabInteractors.Position;
import com.example.robot_3.State.State;

public interface PositionSubscriber {
    void update(Position pos, Cell[][] lab, int dim, State state);

}
