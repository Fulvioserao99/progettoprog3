package com.example.robot_3.FactoryMethod;

import com.example.robot_3.FactoryMethod.ILabyrinth;

public abstract class LabCreator {
    public abstract ILabyrinth createLab();
}
