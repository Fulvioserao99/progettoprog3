package com.example.robot_3.State;

import com.example.robot_3.LabInteractors.Cell;
import com.example.robot_3.Multimap.MultiMap;
import com.example.robot_3.Strategy.AntColonyOneCell;
import com.example.robot_3.Strategy.Strategy;

import java.util.ArrayList;

public class PursuitState implements State {

    private Cell cell;
    Strategy strategy;

    public PursuitState(MultiMap<Integer, Integer> edges, Cell cell){
        this.strategy = new AntColonyOneCell(edges);
        this.cell = cell;
    }


    @Override
    public ArrayList<Integer> doAction(Cell cell) {
        return strategy.calculateNextMove(cell);
    }
}
