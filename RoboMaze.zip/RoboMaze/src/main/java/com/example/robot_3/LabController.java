package com.example.robot_3;

import com.example.robot_3.Command.LabCommand;
import com.example.robot_3.Game.Game;
import com.example.robot_3.LabInteractors.Cell;
import com.example.robot_3.LabInteractors.CellVal;
import com.example.robot_3.Observer.ExampleSub;
import com.example.robot_3.Proxy.IFile;
import com.example.robot_3.Proxy.ProxyFileScoreboard;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Duration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class LabController extends Window {


    @FXML
    Label punteggio;
    @FXML
    Button playBTN, continueBTN;
    @FXML
    Rectangle Robot;
    @FXML
    ArrayList<Rectangle> matrix;
    @FXML
    Label LabelNome, labelGameOver, labelRobotState;

    @FXML
    ListView<String> list;
    private Cell[][] Field;
    private Game instance;
    private ExampleSub example;
    private int steps = 0;
    private Timeline timeline;
    private final LabCommand command;


    public LabController(LabCommand command){
        this.command = command;
    }

    public void initialize() {
        instance = new Game(command.diff);
        example = new ExampleSub();
        LabelNome.setText(command.nome + " " + command.cognome);
    }

    public void onPlayButton(){
        playBTN.setDisable(true);
        instance.subscribe(example);

        timeline = new Timeline(new KeyFrame(Duration.seconds(2), event -> {
            instance.notifySubscribers();
            steps++;
            punteggio.setText("Steps: " + steps);
            instance.move();
            instance.updateCells();
            Field = example.getLab();
            this.setLabColors();
            instance.notifySubscribers();
            labelRobotState.setText(example.getState());


            if (instance.getRobotPos() == instance.goal())
                this.afterGame();


            Robot.setLayoutX((Robot.getLayoutX() + (example.getUpdate().getY() * 50)));
            Robot.setLayoutY(((Robot.getLayoutY() + (example.getUpdate().getX() * 50))));
        }));

        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }

    public void setLabColors(){
        for(int i = 0; i < example.getDim(); i++)
            for(int j = 0; j < example.getDim(); j++)
                if(Field[i][j].getValue() == CellVal.wall) { }
                else
                {
                    if(Field[i][j].getValue() == CellVal.cyan)
                        matrix.get(i*example.getDim() + j).setFill(Color.CYAN);
                    else if(Field[i][j].getValue() == CellVal.red)
                        matrix.get(i*example.getDim() + j).setFill(Color.RED);
                    else if(Field[i][j].getValue() == CellVal.green)
                        matrix.get(i*example.getDim() + j).setFill(Color.GREEN);
                    else if(Field[i][j].getValue() == CellVal.yellow)
                        matrix.get(i*example.getDim() + j).setFill(Color.YELLOW);
                    else
                        matrix.get(i*example.getDim() + j).setFill(Color.GREY);
                }

    }



    public void onContinueButton(ActionEvent event) throws IOException {
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.close();
        Stage stageMenu = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main-menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stageMenu.setTitle("RoboMaze");
        stageMenu.setResizable(false);
        stageMenu.setScene(scene);
        stageMenu.show();
    }

    private void afterGame(){
        timeline.stop();
        labelGameOver.setVisible(true);
        continueBTN.setVisible(true);
        list.getItems().addAll(saveOnFile());
        createScoreWindow();

    }

    private ArrayList<String> saveOnFile(){

        IFile scoreboard = new ProxyFileScoreboard(command.filename,command.nome,command.cognome,steps);
        try {
            scoreboard.write();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        ArrayList<String> s;
        try {
            s = ProxyFileScoreboard.listViewRead(scoreboard);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return s;

    }

    private void createScoreWindow(){
        StackPane secondaryLayout = new StackPane();
        secondaryLayout.getChildren().add(list);
        File css = new File("src/main/resources/Style/scoreboardFinale.css");
        Scene secondScene = new Scene(secondaryLayout, 300, 300);
        secondScene.getStylesheets().add(css.toURI().toString());
        Stage newWindow = new Stage();
        newWindow.setTitle("Scoreboard");
        newWindow.setScene(secondScene);
        newWindow.initOwner(this);
        list.setVisible(true);
        newWindow.show();
    }


}