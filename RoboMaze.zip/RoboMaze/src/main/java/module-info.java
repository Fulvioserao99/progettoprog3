module com.example.robot_3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.robot_3 to javafx.fxml;
    exports com.example.robot_3;
    exports com.example.robot_3.Strategy;
    opens com.example.robot_3.Strategy to javafx.fxml;
    exports com.example.robot_3.State;
    opens com.example.robot_3.State to javafx.fxml;
    exports com.example.robot_3.Proxy;
    opens com.example.robot_3.Proxy to javafx.fxml;
    exports com.example.robot_3.Command;
    opens com.example.robot_3.Command to javafx.fxml;
    exports com.example.robot_3.Observer;
    opens com.example.robot_3.Observer to javafx.fxml;
    exports com.example.robot_3.FactoryMethod;
    opens com.example.robot_3.FactoryMethod to javafx.fxml;
    exports com.example.robot_3.Graph;
    opens com.example.robot_3.Graph to javafx.fxml;
    exports com.example.robot_3.Multimap;
    opens com.example.robot_3.Multimap to javafx.fxml;
    exports com.example.robot_3.ACO;
    opens com.example.robot_3.ACO to javafx.fxml;
    exports com.example.robot_3.LabInteractors;
    opens com.example.robot_3.LabInteractors to javafx.fxml;
    exports com.example.robot_3.Game;
    opens com.example.robot_3.Game to javafx.fxml;
}