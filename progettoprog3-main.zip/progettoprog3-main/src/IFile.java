public interface IFile {

    public void open();
    public void write();
    public void read();
    public void close();

}
