import java.util.ArrayList;

public interface State {
    public ArrayList<Integer> doAction(Cell cell);
}
