public interface PositionSubscriber {
    public void update(Position pos, Cell[][] lab, int dim);

}
