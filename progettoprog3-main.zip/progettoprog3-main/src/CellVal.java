public enum CellVal {

        wall,

        empty,

        green,

        cyan,

        red,

        yellow
}
