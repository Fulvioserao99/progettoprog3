public interface ILabyrinth {
    public void generateLab();
    public void createGraph();

}
