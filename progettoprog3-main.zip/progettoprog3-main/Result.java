import java.io.IOException;

public interface Result {
    public void writeResult(String name, String surname, int solution) throws IOException;
}
