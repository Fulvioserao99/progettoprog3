package com.example.robot_3;

public interface ILabyrinth {
    public void generateLab();
    public void createGraph();

}
