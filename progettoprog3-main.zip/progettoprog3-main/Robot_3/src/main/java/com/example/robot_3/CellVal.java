package com.example.robot_3;

public enum CellVal {

        wall,

        empty,

        green,

        cyan,

        red,

        yellow
}
