public class SeekState implements State{
    @Override
    public void doAction() {
        //
    }
}
