import java.util.ArrayList;

public class AntColonyTwoCells implements Strategy{

    @Override
    public Cell calculateNextMove(Cell[][] lab, int dim) {
        return null;
    }
}
