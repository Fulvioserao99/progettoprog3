public class FleeState implements State{
    @Override
    public void doAction() {
        //
    }
}
