public class EvadeState implements State {
    @Override
    public void doAction() {
        //
    }
}
