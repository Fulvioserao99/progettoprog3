public class PursuitState implements State {
    @Override
    public void doAction() {
        //
    }
}
