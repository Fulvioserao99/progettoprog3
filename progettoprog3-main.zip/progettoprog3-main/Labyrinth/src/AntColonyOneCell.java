import java.util.ArrayList;

public class AntColonyOneCell implements Strategy{

    @Override
    public Cell calculateNextMove(Cell[][] lab, int dim) {
        return null;
    }
}
