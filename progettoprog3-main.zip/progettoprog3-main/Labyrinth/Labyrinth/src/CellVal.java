public enum CellVal {

        wall,

        empty,

        crossed,

        green,

        cyan,

        red,

        yellow
}
