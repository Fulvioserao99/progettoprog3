public interface iBuildLab {
    void createMatrix();
    void CreateExtWall(int x1, int y1, int x2, int y2);
    void CreateIntWall(int x1, int y1, int x2, int y2);
}
