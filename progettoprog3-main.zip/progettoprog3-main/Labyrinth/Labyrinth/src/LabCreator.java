public abstract class LabCreator {
    public abstract ILabyrinth createLab();
}
