import java.util.Map;
import java.util.Vector;

public class RandomMove implements Strategy {
    public Vector<Integer> calculateNextMove(Map<Pair<Integer, Integer>, Integer> edge, int source, int dest) {
     //da implementare maremma maiala


    }
}
