package com.example.robot_3;

public abstract class LabCreator {
    public abstract ILabyrinth createLab();
}
