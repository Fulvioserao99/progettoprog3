package com.example.robot_3;

import javafx.event.Event;

import java.io.IOException;

public abstract class LabCommand {

    protected String nome;
    protected String cognome;
    protected String filename;
    protected int diff;

    LabCommand(String nome, String cognome, String filename){

        this.nome = nome;
        this.cognome = cognome;
        this.filename = filename;

    }

    abstract void loadLab(Event event) throws IOException;

}
