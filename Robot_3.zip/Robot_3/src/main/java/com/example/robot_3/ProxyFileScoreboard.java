package com.example.robot_3;

import java.io.File;

public class ProxyFileScoreboard implements IFile{

    File scoreboard;

    ProxyFileScoreboard(){
        //scoreboard = new File()
    }

    @Override
    public void open() {

    }

    @Override
    public void close() {

    }

    @Override
    public void write() {

    }

    @Override
    public void read() {

    }
}
