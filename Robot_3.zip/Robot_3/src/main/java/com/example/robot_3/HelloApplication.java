package com.example.robot_3;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.effect.ImageInput;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class HelloApplication extends Application {
    @FXML
    Label labelEasy,labelMed,labelHard,leaderboard;
    @FXML
    ListView<String> viewEasy;
    @FXML
    ListView<String> viewMed,viewHard;

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("main-menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1280, 720);
        stage.setTitle("Robot 3");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    Button playBTN, optionsBTN, exitBTN, easyBTN, mediumBTN, hardBTN;

    @FXML
    TextField Text1,Text2;

    @FXML
    Label Label1,Label2;

    //Metodo che regola la visualizzazione dell'interfaccia grafica una volta premuto il bottone "Play" del main menu.
    @FXML
    public void playScene() throws IOException {
        playBTN.setVisible(false);
        optionsBTN.setVisible(false);
        exitBTN.setVisible(false);

        leaderboard.setVisible(true);
        labelEasy.setVisible(true);
        labelMed.setVisible(true);
        labelHard.setVisible(true);
        viewEasy.setVisible(true);
        viewMed.setVisible(true);
        viewHard.setVisible(true);
        Label1.setVisible(true);
        Label2.setVisible(true);
        Text1.setVisible(true);
        Text2.setVisible(true);
        easyBTN.setVisible(true);
        mediumBTN.setVisible(true);
        hardBTN.setVisible(true);
        ArrayList<String> s;

        ProxyFileScoreboard file = new ProxyFileScoreboard("easyscore.txt");
        s = file.listViewRead();
        viewEasy.getItems().addAll(s);
        file = new ProxyFileScoreboard("mediumscore.txt");
        s = file.listViewRead();

        viewMed.getItems().addAll(s);
        file = new ProxyFileScoreboard("hardscore.txt");
        s = file.listViewRead();
        viewHard.getItems().addAll(s);
    }

    //Metodo per il controllo della corretta compilazione del campo "Nome" nel main menu.
    @FXML
    public void canPlayText1(){

        if(!Objects.equals(Text2.getText(), "")){
            easyBTN.setDisable(false);
            mediumBTN.setDisable(false);
            hardBTN.setDisable(false);
        }

    }

    //Metodo per il controllo della corretta compilazione del campo "Cognome" nel main menu.
    @FXML
    public void canPlayText2(){

        if(!Objects.equals(Text1.getText(), "")){
            easyBTN.setDisable(false);
            mediumBTN.setDisable(false);
            hardBTN.setDisable(false);
        }
    }

    //Metodo per le funzionalità del bottone "Exit" nel main menu.
    @FXML
    public void exit(ActionEvent event)
    {
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    //Metodo per il caricamento del labirinto livello di difficoltà facile.
    @FXML
    public void easyPlay(ActionEvent event) throws IOException
    {
        LoadEasyLab loadMaze = new LoadEasyLab(Text1.getText(),Text2.getText(),"easyscore.txt");
        loadMaze.loadLab(event);
    }
    //Metodo per il caricamento del labirinto livello di difficoltà medio.
    @FXML
    public void mediumPlay(ActionEvent event) throws IOException
    {
        LoadMediumLab loadMaze = new LoadMediumLab(Text1.getText(),Text2.getText(),"mediumscore.txt");
        loadMaze.loadLab(event);
    }
    //Metodo per il caricamento del labirinto livello di difficoltà difficile.
    @FXML
    public void hardPlay(ActionEvent event) throws IOException
    {
        LoadHardLab loadMaze = new LoadHardLab(Text1.getText(),Text2.getText(),"hardscore.txt");
        loadMaze.loadLab(event);
    }

    public static void main(String[] args){
        launch();
    }
}