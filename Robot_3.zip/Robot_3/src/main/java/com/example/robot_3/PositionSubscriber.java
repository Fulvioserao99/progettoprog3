package com.example.robot_3;

public interface PositionSubscriber {
    void update(Position pos, Cell[][] lab, int dim);

}
