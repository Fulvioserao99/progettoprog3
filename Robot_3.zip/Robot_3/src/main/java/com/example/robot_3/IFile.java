package com.example.robot_3;

public interface IFile {

    public void open();
    public void write();
    public void read();
    public void close();

}
