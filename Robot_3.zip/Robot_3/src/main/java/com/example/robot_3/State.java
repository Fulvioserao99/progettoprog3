package com.example.robot_3;

import java.util.ArrayList;

public interface State {
    ArrayList<Integer> doAction(Cell cell);

}
