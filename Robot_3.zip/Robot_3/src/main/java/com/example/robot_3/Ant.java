package com.example.robot_3;

import java.util.ArrayList;

public class Ant {

    private int time;

    private ArrayList<Cell> visited;











}
