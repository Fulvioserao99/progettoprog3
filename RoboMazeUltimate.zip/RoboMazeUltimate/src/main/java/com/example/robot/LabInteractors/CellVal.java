package com.example.robot.LabInteractors;

/**
 * Enum che determina la tipologia della cella*/
public enum CellVal {

        wall,

        empty,

        green,

        cyan,

        red,

        yellow
}
