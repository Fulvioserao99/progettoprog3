package com.example.robot_3.LabInteractors;

/**
 * Enum che determina la tipologia della cella*/
public enum CellVal {

        wall,

        empty,

        green,

        cyan,

        red,

        yellow
}
