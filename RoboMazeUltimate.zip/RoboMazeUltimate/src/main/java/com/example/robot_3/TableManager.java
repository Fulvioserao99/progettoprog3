package com.example.robot_3;

import com.example.robot_3.Proxy.IFile;
import com.example.robot_3.Proxy.ProxyFileScoreboard;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class TableManager {

    public static void setConstraints(TableColumn player, TableColumn points)
    {
        player.setResizable(false);
        points.setResizable(false);
        player.setReorderable(false);
        points.setReorderable(false);
        player.setSortable(false);
        points.setSortable(false);
    }

    public static void tableUpdater(String filename, TableColumn player, TableColumn points, TableView table) throws IOException {
        IFile scoreboard = new ProxyFileScoreboard(filename);
        ArrayList<String[]> strings = scoreboard.read();
        ObservableList<PlayerProperty> data = FXCollections.observableArrayList();
        for (String[] s:strings)
            data.add(new PlayerProperty(s[0],s[1]));

        player.setCellValueFactory(new PropertyValueFactory<PlayerProperty,String>("player"));
        points.setCellValueFactory(new PropertyValueFactory<PlayerProperty,String>("pnt"));
        setConstraints(player, points);
        table.setItems(data);
    }


}
