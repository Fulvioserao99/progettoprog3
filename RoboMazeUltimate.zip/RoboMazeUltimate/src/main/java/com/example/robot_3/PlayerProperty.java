package com.example.robot_3;

import javafx.beans.property.SimpleStringProperty;

public class PlayerProperty {
    private SimpleStringProperty player;
    private SimpleStringProperty pnt;

    public PlayerProperty(String player, String pnt){
        this.player = new SimpleStringProperty(player);
        this.pnt = new SimpleStringProperty(pnt);
    }

    public String getPnt() {
        return pnt.get();
    }

    public String getPlayer() {
        return player.get();
    }

    public void setPlayer(String player) {
        this.player.set(player);
    }

    public void setPnt(String pnt) {
        this.pnt.set(pnt);
    }
}
