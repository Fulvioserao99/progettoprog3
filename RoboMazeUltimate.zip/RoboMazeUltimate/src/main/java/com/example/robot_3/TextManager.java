package com.example.robot_3;

import javafx.geometry.Side;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;

import java.util.Objects;
import java.util.function.UnaryOperator;

public class TextManager {

    public static boolean textConstraints(TextField text1, TextField text2)
    {
        if(!Objects.equals(text1.getText(), "") && !Objects.equals(text2.getText(), "")) {
            return false;
        }
        else
        {
            return true;
        }
    }

    public static void textLength(TextField text)
    {
        int len = 12;

        UnaryOperator<TextFormatter.Change> rejectChange = c -> {
            if (c.isContentChange()) {
                if (c.getControlNewText().length() > len) {
                    final ContextMenu menu = new ContextMenu();
                    menu.getItems().add(new MenuItem("This field takes\n"+len+" characters only."));
                    menu.show(c.getControl(), Side.BOTTOM, 0, 0);
                    return null;
                }
            }
            return c;
        };

        text.setTextFormatter(new TextFormatter(rejectChange));
    }
}
