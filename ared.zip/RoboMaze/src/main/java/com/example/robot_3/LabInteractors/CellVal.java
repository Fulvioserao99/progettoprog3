package com.example.robot_3.LabInteractors;

public enum CellVal {

        wall,

        empty,

        green,

        cyan,

        red,

        yellow
}
