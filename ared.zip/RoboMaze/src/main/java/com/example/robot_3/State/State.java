package com.example.robot_3.State;

import com.example.robot_3.LabInteractors.Cell;

import java.util.ArrayList;

public interface State {
    ArrayList<Integer> doAction(Cell cell);
}
