package com.example.robot_3.Game;

import com.example.robot_3.FactoryMethod.*;
import com.example.robot_3.LabInteractors.Cell;
import com.example.robot_3.LabInteractors.CellVal;
import com.example.robot_3.LabInteractors.Position;
import com.example.robot_3.LabInteractors.Robot;
import com.example.robot_3.Observer.PositionSubscriber;
import com.example.robot_3.State.EvadeState;
import com.example.robot_3.State.FleeState;
import com.example.robot_3.State.PursuitState;
import com.example.robot_3.State.SeekState;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
public class Game {

    private Labyrinth lab;

    private Robot robot;

    private ArrayList<PositionSubscriber> subscribers;

    private Boolean firstMove;


    //file?

    public Game(int difficolta){

        LabCreator labi;


        switch (difficolta) {
            case 1 -> {
                labi = new EasyLabCreator();
                this.lab = labi.createLab();
            }
            case 2 -> {
                labi = new MediumLabCreator();
                this.lab = labi.createLab();
            }
            case 3 -> {
                labi = new HardLabCreator();
                this.lab = labi.createLab();
            }
        }

        assert lab != null;
        this.robot = new Robot(lab.getCellById(0),new PursuitState(this.lab.getEdges(), lab.getCellById(0)));
        subscribers = new ArrayList<>();
        firstMove = true;

    }

    public void subscribe(PositionSubscriber o){
        subscribers.add(o);
    }

    public void unSubscribe(PositionSubscriber o){
        subscribers.remove(o);
    }

    public void notifySubscribers(){
        for (PositionSubscriber o:subscribers) {
            o.update(this.robot.getPositionCoords(),this.getLab(),this.lab.getDim(), this.robot.getRobotState());
        }
    }

    public Cell[][] getLab() {
        return this.lab.getLab();
    }

    public void updateCells(){
        int randomNum;
        Cell[][] maze = this.lab.getLab();
        for(int i=0; i<this.lab.getDim(); i++)
            for(int j=0; j<this.lab.getDim(); j++) {

               if (firstMove) {
                   firstMove = false;
                if( i == 0 && j ==0)
                    continue;
               }


                if (maze[i][j].getValue() != CellVal.wall && maze[i][j] != maze[this.lab.getDim() - 1][this.lab.getDim() - 1]) {
                    randomNum = ThreadLocalRandom.current().nextInt(0, 12);
                    if (randomNum < 4)
                        maze[i][j].setValue(CellVal.empty);
                    else if (randomNum < 6)
                        maze[i][j].setValue(CellVal.yellow);
                    else if (randomNum < 8)
                        maze[i][j].setValue(CellVal.red);
                    else if (randomNum < 10)
                        maze[i][j].setValue(CellVal.cyan);
                    else if (randomNum < 12)
                        maze[i][j].setValue(CellVal.green);
                }
            }
    }

    public Position goal(){
        return this.lab.getEndPos();
    }

    public ArrayList<Integer> nextMove(){
        return this.robot.doAction(this.robot.getActualCell());
    }

    public Position getRobotPos(){
        return this.robot.getPositionCoords();
    }

    public void move() {
        ArrayList<Integer> nextMove;


        if (this.robot.getActualCellValue() == CellVal.empty) {

            nextMove = nextMove();
            this.robot.setActualCell(this.lab.getCellById(nextMove.get(0)));

        }
        else if (this.robot.getActualCellValue() == CellVal.green) {

            this.robot.setRobotState(new PursuitState(this.lab.getEdges(), this.robot.getActualCell()));
            nextMove = nextMove();
            this.robot.setActualCell(this.lab.getCellById(nextMove.get(0)));

        }
        else if (this.robot.getActualCellValue() == CellVal.red) {

            this.robot.setRobotState(new SeekState(this.lab.getEdges(), this.robot.getActualCell()));
            nextMove = nextMove();
            this.robot.setActualCell(this.lab.getCellById(nextMove.get(0)));

        }
        else if (this.robot.getActualCellValue() == CellVal.yellow) {

            this.robot.setRobotState(new FleeState(this.lab.getEdges(), this.robot.getActualCell()));
            nextMove = nextMove();
            this.robot.setActualCell(this.lab.getCellById(nextMove.get(0)));

        }
        else if (this.robot.getActualCellValue() == CellVal.cyan) {

            this.robot.setRobotState(new EvadeState(this.robot.getActualCell(), this.lab.getEdges()));
            nextMove = nextMove();
            this.robot.setActualCell(this.lab.getCellById(nextMove.get(0)));

        }

    }
}
