package com.example.robot_3.State;

import com.example.robot_3.LabInteractors.Cell;
import com.example.robot_3.Multimap.MultiMap;
import com.example.robot_3.Strategy.AntColonyTwoCells;
import com.example.robot_3.Strategy.Strategy;

import java.util.ArrayList;

public class FleeState implements State{

    private Cell cell;
    Strategy strategy;

    public FleeState(MultiMap<Integer, Integer> edges, Cell cell){
        this.strategy = new AntColonyTwoCells(edges);
        this.cell = cell;
    }


    @Override
    public ArrayList<Integer> doAction(Cell cell) {
        return strategy.calculateNextMove(cell);
    }
}
