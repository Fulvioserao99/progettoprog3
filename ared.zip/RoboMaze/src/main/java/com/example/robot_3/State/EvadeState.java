package com.example.robot_3.State;

import com.example.robot_3.LabInteractors.Cell;
import com.example.robot_3.Multimap.MultiMap;
import com.example.robot_3.Strategy.RandomMove;
import com.example.robot_3.Strategy.Strategy;

import java.util.ArrayList;

public class EvadeState implements State {

    private Cell cell;
    Strategy strategy;

    public EvadeState(Cell cell, MultiMap<Integer, Integer> edges){
        this.strategy = new RandomMove(edges);
        this.cell = cell;
    }


    @Override
    public ArrayList<Integer> doAction(Cell cell) {
        return strategy.calculateNextMove(cell);
    }
}
